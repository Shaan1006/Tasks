
import java.util.*;
public class DriverCode {

	public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         //Since giving 81 values is a task, I have got added a default sudoku where in you can change the values and check. 
         System.out.println("Do you want to use default sudoku or custom one? Type in:'1' for custom values and '2' for default Values.");
         Integer s = sc.nextInt();
         if(s == 1) {
                        int[][] soduku= new int[9][9];
                        
                        System.out.println("Enter the Soduku in row wise manner");
                        for(int i=0;i<9;i++) {
        	                 for(int j=0;j<9;j++) {
        	                      System.out.println("Enter the "+(i+1)+" th row  " +(j+1)+" th coloumn number");
        	                       int x  = sc.nextInt();
        	                       if(x<10 && x>0) {
        	    	                 soduku[i][j] = x;}
        	                       else {
        	    	                   System.out.println("Enter a valid number between 1 & 9.Code Shutting down.run again");
        	    	                      return;
        	                           }
                                }
                            }
                         sc.close();
                         Sodukucheckmain  object = new Sodukucheckmain();
                         String isitvalidsoduku;
                         isitvalidsoduku = object.isValidSudoku(soduku);
                          System.out.println("The Given Soduku is" +isitvalidsoduku);            
                        }
        
         else if(s==2){            
        	  // This is a default Sudoku wherein we can change values and check the algorithm designed is working correctly or not.
                            int[][] defaultboard = { { 5,9,1,2,7,4,8,3,6}, 
                                          { 4,7,8,5,3,6,9,1,2 }, 
                                          { 3,2,6,1,8,9,5,4,7 }, 
                                          {  2,5,7,6,9,3,4,8,1}, 
                                          {  6,8,9,4,1,5,2,7,3}, 
                                          {  1,4,3,8,2,7,6,9,5}, 
                                          { 7,6,4,9,5,1,3,2,8 }, 
                                          { 9,1,2,3,6,8,7,5,4 }, 
                                          { 8,3,5,7,4,2,1,6,9 } }; 
                             for(int p = 0;p<9;p++) {  
                                    for(int q=0;q<9;q++) {
    	                               System.out.print(defaultboard[p][q]+"\t");          
                                      }
                                     System.out.println("");    
                             }
                             sc.close();
                             Sodukucheckmain  object = new Sodukucheckmain();
                             String isitvalidsoduku;
                             isitvalidsoduku = object.isValidSudoku(defaultboard);
                             System.out.println("The Given Soduku " +isitvalidsoduku);            
                            
                             
                             
                             
                             
         
                  
 
	}
}
}


import java.util.*;
public class Sodukucheckmain{
    public String isValidSudoku(int[][] board) {
        int m = board.length; int n = board[0].length;
        
        //row wise checking whether a duplicate is present or not
        for(int rowIndex=0; rowIndex < m; rowIndex++){
            if(checkForDuplicates(board, rowIndex, rowIndex+1, 0, n)){
                return "has Duplicates in row "+(rowIndex+1);  
            }
        }
        
        //Column wise checking for duplicates
        for(int colIndex=0; colIndex < m; colIndex++){
            if(checkForDuplicates(board, 0 , m , colIndex, colIndex+1)){
            	return "has Duplicates in Coloumn "+(colIndex+1);  
            }
        }
        
        //grid wise checking
        int sqrt = (int) Math.sqrt(m);
        for(int rowIndex=0; rowIndex < m ; rowIndex +=  sqrt){
            for(int colIndex=0; colIndex < n ; colIndex += sqrt){
                if(checkForDuplicates(board, rowIndex , rowIndex+sqrt , colIndex, colIndex+sqrt)){
                	return "has Duplicates in grid "+rowIndex+colIndex;  
                }        
            }
        }
        return "is Perfectly Valid";
    }
    
    
     public boolean checkForDuplicates(int[][] board, int rowStart, int rowEnd, int colStart, int colEnd) {
         Set<Integer> hash = new HashSet<>();    
         for(int i= rowStart; i < rowEnd; i++){
            for(int j= colStart; j < colEnd; j++){
                if(hash.contains(board[i][j])){
                    return true;
                 }
                 hash.add(board[i][j]);
             }
         }
        return false; 
     }
}
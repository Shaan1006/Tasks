import java.util.*;
public class MyComparator implements Comparator {
    public int compare(Object obj1, Object obj2 ) {
    	  HashMap h1= (HashMap)obj1;    	
    	  HashMap h2= (HashMap)obj2;
    	  Set s1 = h1.entrySet();
    	  Set s2 = h2.entrySet();
    	  Iterator i1=s1.iterator();
    	  Iterator i2=s2.iterator();
       	  HashMap.Entry m1 = (HashMap.Entry)i1.next();
       	  HashMap.Entry m2 = (HashMap.Entry)i2.next();
    	int v1 = (int)m1.getKey();
    	int v2 = (int)m2.getKey();
    	if(v1<v2)
	       return -1;
    	else if(v2<v1)
    		return +1;
    	else
    		return 0;
    	
    	
    }
}

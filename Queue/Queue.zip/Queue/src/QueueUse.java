//Simple replica of Shortest Job First Scheduling Algorithm (non preemptive)
import java.util.*;
public class QueueUse {

	public static void main(String[] args) throws InterruptedException {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of processess you want to enter ");
    int n = sc.nextInt();
    LinkedList<HashMap> queue = new LinkedList<>();
    for(int i=0;i<n;i++) {
    	HashMap k = new HashMap();
    	System.out.println("Enter Process Execution time(in seconds) and it's Id ");
        int value =sc.nextInt();
        sc.nextLine();
        String s = sc.nextLine();
        k.put(value,s);
        queue.add(k);
    }
    //System.out.print(queue); 
    Collections.sort(queue,new MyComparator());
    //System.out.print(queue);just to see the sorted array list of Maps.
    /////Running Process from their respective execution time here
    sc.close();
    Iterator i = queue.iterator();
    while(i.hasNext()) {
    	HashMap x = new HashMap();
    	x = queue.poll();
    	Set s1 = x.entrySet();
    	Iterator i1=s1.iterator();
    	HashMap.Entry m1 = (HashMap.Entry)i1.next();
    	int v1 = (int)m1.getKey();
    	System.out.println("Process is going to complete it's execution in time "+v1+"secs");
    	synchronized(Thread.currentThread()){
    	Thread.currentThread().wait((v1*1000));
    	}
    }
    System.out.println("All the processess have completed their execution");
	}

}

import java.util.*;
public class implementation_str {
	      static String s = "Indium Software is the best Place to work";
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//Length()
		System.out.println("Length of the String is"+ s.length());
		//charAt()
		System.out.println("Enter the position you find the character of");
		int x = sc.nextInt();
		System.out.println("Character at position "+x+"is"+s.charAt(x));
		//equals()
		System.out.println("Enter the string with which you want to compare(equality)");
		String y = sc.next();
		System.out.println("Check two strings are equal or not :"+s.equals(y));
	    //compare to
		System.out.println("Enter two strings which yo want to compare lexicographically");
		String str1 = sc.next();
		String str2 = sc.next();
		int var1 = str1.compareTo(str2);
	    System.out.println("str1 & str2 comparison: "+var1);   
	    // Starts with
	       System.out.println("str1 to check starts with");
	       String str3 = sc.next();
	       System.out.println("str2");
	       String str4 = sc.next();
	       System.out.println("String str starts with or not : "+str3.startsWith(str4));
	   // ends with    
	       System.out.println("str1 to check ends with");
	       String str5 = sc.next();
	       System.out.println("str2");
	       String str6 = sc.next();
	       System.out.println("String str starts with or not : "+str5.endsWith(str6));
      // Indexof
	       int index2=s.indexOf("ul");
	       System.out.println(index2);
	  //Substring
	       System.out.println("Substring starting from index 15 and ending at 20:");
	       System.out.println(s.substring(2,10));
	  //valueof
	       int number = 5055;
	   	String str = String.valueOf(number);  
	   	System.out.println(str+s);
	   	//Concat  	
	   String s1 = s.concat("Ezhil Ma'am").concat("is").concat("the best");
	   System.out.println(s1);
	   //replace
	   System.out.print("String after replacing all 'o' with 'p' :" );
		System.out.println(str.replace('u', 'o'));
       //trim
		String str10 = new String("     Java is the easiest Programming language        ");
		System.out.println("String before trim: "+str10);
		System.out.println("String after trim: "+str10.trim());
	   //toCharArray
		 String str11 = new String("A Sentence with 4 spaces");
	       char[] array= str11.toCharArray();
	       System.out.print("Content of Array:");
	       for(char c: array){
	           System.out.print(c);}
	  //equalsIgnorecase
	           String s55="INDIUM";  
	           String s44="indium";  
	           System.out.println(s55.equalsIgnoreCase(s44));//true because content and case both are same       
		 sc.close();
		}
	}
